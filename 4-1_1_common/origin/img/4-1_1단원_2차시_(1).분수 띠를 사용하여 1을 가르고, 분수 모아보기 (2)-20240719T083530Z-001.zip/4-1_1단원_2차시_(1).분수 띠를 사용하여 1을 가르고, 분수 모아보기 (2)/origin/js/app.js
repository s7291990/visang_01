import {
  setCommonRoot,
  autoScale,
  // toggleFullScreen,
  fullScreenChangeHandler,
} from "./common.js";
import anime from "./anime.js";

var metaUrl = import.meta.url;
var root = null;

window.addEventListener("script-loaded", function (ev) {
  if (root) return;
  const u = new URL(metaUrl);
  const param = u.searchParams.get("embed-unique");

  if (param && param !== ev.detail.unique) return;

  const shadowRoot = ev.detail.root; // 커스텀 이벤트에 담겨진 shadowRoot 객체
  root = shadowRoot;

  setCommonRoot(root, {});

  let isResetClicked = false;
  let isClicked = false;
  let isLastClicked = false;

  const guideHand = root.querySelector("#guide_hand");

  let guideHandAnimation;
  const setGuideHandAnimation = () => {
    if (isLastClicked) {
      return;
    }
    guideHand.style.display = "block";
    guideHand.style.zIndex = 1000;
    guideHandAnimation = anime({
      targets: guideHand,
      opacity: [1, 0],
      loop: 3,
      duration: 1000,
      easing: "easeInOutQuad",
      update: () => {
        if (isClicked) {
          // pauseHandAnimation();
        }
      },
      complete: () => {
        setTimeout(() => {
          guideHand.style.opacity = 1;
        }, 500);
      },
    });
    guideHandAnimation.play();
  };

  const pauseHandAnimation = () => {
    guideHand.style.display = "none";
    guideHand.style.opacity = 0;
    guideHand.style.zIndex = -999;
    if (guideHandAnimation) {
      guideHandAnimation.pause();
      guideHandAnimation = null;
    }
  };

  window.addEventListener("resize", function () {
    autoScale();
  });
  autoScale();

  let animation;

  const stopAnimation = () => {
    if (isResetClicked) {
      pauseAnimation();
    }
  };

  const setAnimation = (options) => {
    animation = anime({
      ...{
        easing: "easeInOutQuad",
        duration: 1200,
        begin: stopAnimation,
        update: stopAnimation,
      },
      ...options,
    });
  };

  const fullScreenBtn = root.querySelector("#full_screen_btn");
  const resetBtn = root.querySelector("#reset_btn");

  const border_1 = root.querySelector("#border_1");
  const border_2 = root.querySelector("#border_2");
  const border_3 = root.querySelector("#border_3");
  const border_4 = root.querySelector("#border_4");
  const border_5 = root.querySelector("#border_5");
  const border_6 = root.querySelector("#border_6");

  const border_1_block = root.querySelector("#border_1_block");
  const border_4_block = root.querySelector("#border_4_block");
  const border_2_block = root.querySelector("#border_2_block");
  const number_3_block = root.querySelector("#number_3_block");

  const part_6 = root.querySelector("#part_6");
  const part_5 = root.querySelector("#part_5");
  const part_2 = root.querySelector("#part_2");
  const part_4 = root.querySelector("#part_4");

  const block_7 = root.querySelector("#block_7");

  const number_1 = root.querySelector("#number_1");
  const number_2 = root.querySelector("#number_2");
  const number_3 = root.querySelector("#number_3");
  const number_3_container = root.querySelector("#number_3_container");
  const number_1_block = root.querySelector("#number_1_block");

  const arrow_1 = root.querySelector("#arrow_1");
  const arrow_2 = root.querySelector("#arrow_2");
  const arrow_3 = root.querySelector("#arrow_3");
  const arrow_4 = root.querySelector("#arrow_4");

  const arrow_1_0 = arrow_1.querySelector("#arrow_1_0");
  const arrow_1_1 = arrow_1.querySelector("#arrow_1_1");

  const arrow_2_0 = arrow_2.querySelector("#arrow_2_0");
  const arrow_2_1 = arrow_2.querySelector("#arrow_2_1");

  const arrow_3_0 = arrow_3.querySelector("#arrow_3_0");
  const arrow_3_1 = arrow_3.querySelector("#arrow_3_1");

  const arrow_4_0 = arrow_4.querySelector("#arrow_4_0");
  const arrow_4_1 = arrow_4.querySelector("#arrow_4_1");

  const colorPalette = {
    pink: "#E4007F",
    blue: "#00AEE4",
    turquoise: "#4E939D",
    purple: "#811EFF",
    black: "#000000",
  };

  const initAction = () => {
    border_1_block.style.display = "block";
    border_2.style.opacity = 1;
    border_1.style.opacity = 1;
    part_2.style.opacity = 1;
    setAnimation({
      targets: [border_1, border_2, border_6],
      stroke: colorPalette.pink,
      complete: () => {
        setTimeout(() => {
          if (border_1_block.style.display !== "none") {
            setGuideHandAnimation();
          }
        }, 400);
        border_1_block.style.display = "block";
      },
    });
  };
  initAction();
  
  // 첫째 줄 네칸 박스 클릭 -> 둘째 줄 네칸 분홍색 박스로 복사
  border_1_block.addEventListener("click", () => {
    border_1_block.style.display = "none";
    pauseHandAnimation();
    
    border_1.setAttribute("style", "opacity: 0;");
    border_2.setAttribute("stroke", colorPalette.pink);
    setAnimation({
      targets: part_2,
      x: [-30, 0],
      y: [-230, 0],
      complete: () => {
        number_1_block.style.display = "block";
        number_1_block.style.opacity = 1;
        if (number_1_block.style.display !== 'none') {
          guideHand.style.top = "529px";
          guideHand.style.left = "1590px";
          setGuideHandAnimation();          
        }
      },
    });
    part_6.style.opacity = 1;
    setAnimation({
      targets: part_6,
      x: [0, 28],
      y: [-460, -230],
    });
  });

  // 첫 번째 (?) 마크 클릭
  number_1_block.addEventListener("click", () => {
    number_1_block.style.display = "none";

    pauseHandAnimation();
    guideHand.style.opacity = 0;
    number_1.style.opacity = 1;
    
    const number_1_path = number_1.querySelectorAll("path");
    number_1_path.forEach((path) => {
      path.style.opacity = 0;
      path.setAttribute("fill", "#E4007F");
    });
    setAnimation({
      targets: number_1_path,
      opacity: [0, 1, 1, 1, 1, 1, 1],
      duration: 1500,
      begin: () => {
        pauseHandAnimation();
        stopAnimation();
      },
      complete: () => {
        // 검은색 테두리 지우기
        setAnimation({
          targets: [border_2, border_6, ...number_1_path],
          opacity: [1, 0],
          duration: 2000,
          complete: () => {
            number_1_path.forEach((path) => {
              path.style.opacity = 0;
              path.setAttribute("fill", "black");
            });
            setAnimation({
              targets: number_1_path, // 검음색 숫자 애니메이션
              opacity: [0, 1, 1, 1, 1, 1, 1],
              duration: 2200,
              complete: arrowAnimation, // 화살표 애니메이션
            });
          },
        });
      },
    });
  });

  const arrowAnimation = () => {
    // 화살표
    arrow_1.style.opacity = 1;
    arrow_2.style.opacity = 1;
    arrow_3.style.opacity = 1;
    arrow_4.style.opacity = 1;

    setAnimation({
      targets: arrow_1_0,
      duration: 240,
      strokeDashoffset: [700, 430],
    });
    setAnimation({
      targets: arrow_1_1,
      duration: 240,
      translateX: [-252, 0],
      translateY: [-80, 0],
    });
    setAnimation({
      targets: arrow_2_0,
      duration: 240,
      strokeDashoffset: [700, 533],
    });
    setAnimation({
      targets: arrow_2_1,
      duration: 240,
      translateX: [140, 0],
      translateY: [-80, 0],
    });
    setAnimation({
      targets: arrow_3_0,
      duration: 240,
      strokeDashoffset: [700, 560],
    });
    setAnimation({
      targets: arrow_3_1,
      duration: 240,
      translateX: [-133, 0],
      translateY: [-50, 0],
    });
    setAnimation({
      targets: arrow_4_0,
      duration: 240,
      strokeDashoffset: [700, 560],
    });
    setAnimation({
      targets: arrow_4_1,
      duration: 240,
      translateX: [133, 0],
      translateY: [-50, 0],
    });

    // 하늘색 테두리
    setTimeout(() => {
      setAnimation({
        targets: number_2.querySelectorAll("path"),
        fill: colorPalette.blue,
      });
      setAnimation({
        targets: [border_4, border_5],
        stroke: colorPalette.blue,
        complete: () => {
          border_4_block.style.display = "block";
          if (border_4_block.style.display !== "none") {
            guideHand.style.top = "536px";
            guideHand.style.left = "464px";
            setGuideHandAnimation();            
          }
        },
      });
    }, 1500);
  };

  border_4_block.addEventListener("click", () => {
    border_4_block.style.display = "none";

    pauseHandAnimation();
    border_5.setAttribute("stroke", colorPalette.blue);
    setAnimation({
      targets: part_5,
      x: [-28, 0],
      y: [-230, 0],
      complete: () => {
        border_2.style.opacity = 1;
        setAnimation({
          targets: border_2,
          stroke: [colorPalette.turquoise, colorPalette.purple],
          complete: () => {
            if (border_2_block.style.display !== "none") {
              guideHand.style.left = "1004px";
              setGuideHandAnimation();            
            }
          },
        });
        setAnimation({
          targets: number_1.querySelectorAll("path"),
          fill: colorPalette.purple,
        });
        border_2_block.style.display = "block";
        border_6.setAttribute("stroke", "");
        border_6.style.opacity = 1;
        setAnimation({
          targets: border_6,
          stroke: colorPalette.purple,
        });
      },
    });
  });

  border_2_block.addEventListener("click", () => {
    border_2_block.style.display = "none";

    pauseHandAnimation();
    border_2.setAttribute("stroke", colorPalette.purple);

    setAnimation({
      targets: number_1.querySelectorAll("path"),
      fill: colorPalette.purple,
      duration: 1,
    });
    setAnimation({
      targets: [part_6, border_3],
      x: [30, 0],
      y: [-229, 0],
      begin: () => {
        pauseHandAnimation();
        stopAnimation();
      },
      complete: () => {
        setAnimation({
          targets: number_3_container,
          opacity: [0, 1],
        });

        setAnimation({
          targets: block_7,
          opacity: [0, 1],
        });

        number_3_block.style.display = "block";
        setAnimation({
          targets: number_3_block,
          opacity: [0, 1],
          complete: () => {
            if (number_3_block.style.display !== "none") {
              guideHand.style.top = "769px";
              guideHand.style.left = "1443px";
              setGuideHandAnimation();             
            }
          },
        });
      },
    });
  });

  number_3_block.addEventListener("click", () => {
    pauseHandAnimation();
    number_3_block.style.display = "none";
    setAnimation({
      targets: number_3,
      opacity: [0, 1],
    });
  });

  // toggle full screen mode btn
  fullScreenBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    // toggleFullScreen();

    var doc = document;
    var docEl = root.firstElementChild;

    var requestFullScreen =
      doc.documentElement.requestFullscreen ||
      doc.mozRequestFullScreen ||
      doc.webkitRequestFullScreen ||
      doc.msRequestFullscreen;
    var cancelFullScreen =
      doc.exitFullscreen ||
      doc.mozCancelFullScreen ||
      doc.webkitExitFullscreen ||
      doc.msExitFullscreen;

    if (
      !doc.fullscreenElement &&
      !doc.mozFullScreenElement &&
      !doc.webkitFullscreenElement &&
      !doc.msFullscreenElement
    ) {
      requestFullScreen.call(docEl);
      // 전체화면 이미지로 변경
      root.querySelector("#full_screen_btn > img").src = new URL(
        "../img/btn-fullscreen-off.png",
        metaUrl
      ).href;
    } else {
      cancelFullScreen.call(doc);
      // 일반 이미지로 변경
      root.querySelector("#full_screen_btn > img").src = new URL(
        "../img/btn-fullscreen-on.png",
        metaUrl
      );
    }
  });

  const pauseAnimation = () => {
    if (animation) {
      animation.pause();
      animation = null;
    }
  };

  // esc key -> escape full mode
  if (document.addEventListener) {
    document.addEventListener(
      "fullscreenchange",
      fullScreenChangeHandler,
      false
    );
    document.addEventListener(
      "mozfullscreenchange",
      fullScreenChangeHandler,
      false
    );
    document.addEventListener(
      "MSFullscreenChange",
      fullScreenChangeHandler,
      false
    );
    document.addEventListener(
      "webkitfullscreenchange",
      fullScreenChangeHandler,
      false
    );
  }

  // reset btn
  resetBtn.addEventListener("click", (event) => {
    event.stopPropagation();

    isResetClicked = true;
    pauseAnimation();
    pauseHandAnimation();
    setTimeout(() => {
      pauseHandAnimation();
    }, 500);

    guideHand.style.top = "310px";
    guideHand.style.left = "847px";

    border_1_block.style.display = "none";
    border_4_block.style.display = "none";
    border_2_block.style.display = "none";
    number_3_block.style.display = "none";
    number_3_block.style.opacity = 0;

    border_2.setAttribute("stroke", "");
    border_1.setAttribute("stroke", "");

    number_1_block.style.display = "none";
    number_1_block.style.opacity = 0;
    number_1.querySelectorAll("path").forEach((path) => {
      path.setAttribute("fill", colorPalette.black);
    });
    number_1.style.opacity = 0;

    number_2.querySelectorAll("path").forEach((path) => {
      path.setAttribute("fill", colorPalette.black);
    });
    border_3.setAttribute("x", "0");
    border_3.setAttribute("y", "-460");
    border_4.setAttribute("stroke", "");
    border_5.setAttribute("stroke", "");

    part_5.setAttribute("x", -28);
    part_5.setAttribute("y", -230);

    arrow_1.style.opacity = 0;
    arrow_2.style.opacity = 0;
    arrow_3.style.opacity = 0;
    arrow_4.style.opacity = 0;

    part_2.style.opacity = 0;
    part_2.setAttribute("x", -29);
    part_2.setAttribute("y", -230);

    part_6.style.opacity = 0;
    number_3.style.opacity = 0;
    number_3_container.style.opacity = 0;
    block_7.style.opacity = 0;

    setTimeout(() => {
      // border_2_block.style.display = 'block';
      // border_4_block.style.display = 'block';
      // number_1_block.style.display = 'block';
      // border_1_block.style.display = 'block';
      // number_3_block.style.display = 'block';
      initAction();
      isResetClicked = false;
      isClicked = false;
      isLastClicked = false;
    }, 1000);
  });
});
